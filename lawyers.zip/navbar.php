<header class="container-fluid bg-dark text-white">
	<div class="container">
		<div class="row align-items-center justify-content-center pt-3 pb-3">
			<div id="logo" class="col-md-3">
				<span class="float-left mr-2"><img id="logo-img" src="img/ico/logo-white.png"></span>
				<span class="font-italic">Юридическая фирма</span><br>
				<span class="font-italic text-uppercase">Колиогло, Черкасова</span><br>
				<span class="font-italic text-uppercase">и партнеры</span>
			</div>
		</div>
	</div>
</header>

<nav class="navbar navbar-expand-lg navbar-light bg-white">
	<div class="container">
		<!-- <a class="navbar-brand" href="#">Navbar</a> -->
		<button class="navbar-toggler m-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto justify-content-between w-100 text-uppercase">
				<li class="nav-item<?php if ($_GET['page'] == 'main' or $_GET['page'] == '') echo ' active'; ?>">
					<a class="pl-0 nav-link" href="main">Главная <span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item<?php if ($_GET['page'] == 'services' or $_GET['page'] == 'service-content') echo ' active'; ?>">
					<a class="nav-link" href="services">Наши услуги</a>
				</li>
				<li class="nav-item<?php if ($_GET['page'] == 'partners') echo ' active'; ?>">
					<a class="nav-link" href="partners">Партнеры и сотрудники</a>
				</li>
				<li class="nav-item<?php if ($_GET['page'] == 'clients') echo ' active'; ?>">
					<a class="nav-link" href="clients">Наши клиенты</a>
				</li>
				<li class="nav-item<?php if ($_GET['page'] == 'news') echo ' active'; ?>">
					<a class="nav-link" href="news">Новости</a>
				</li>
				<li class="nav-item<?php if ($_GET['page'] == 'info') echo ' active'; ?>">
					<a class="nav-link" href="info">Полезная информация</a>
				</li>
				<li class="nav-item<?php if ($_GET['page'] == 'contacts') echo ' active'; ?>">
					<a class="nav-link pr-0 " href="contacts">Контакты</a>
				</li>
			</ul>
		</div>
	</div>
</nav>