<!doctype html>
<html lang="en">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		
		<!-- Style CSS -->
		<link rel="stylesheet" href="css/style.css">
		
		
		<script src="https://kit.fontawesome.com/064ae6a0a2.js"></script>

		<title>Hello, world!</title>
	</head>
	<body>

		<?php include 'navbar.php'; ?>
		
		<div id="main" class="container-fluid">
			<div class="overlay-gradient">
			</div>
			<div class="container pt-5 pb-5">
				<div class="row justify-content-end text-white">
					<div class="col-md-4">
						<div class="row">
							<div class="col">
								<h4>Колиогло Елена</h4>
								<p class="mb-1"><i class="fas fa-phone-alt"></i> 8-800-800-80-80</p>
								<p><i class="fas fa-envelope"></i> mail@mail.ru</p>
							</div>
						</div>
						<div class="row">
							<div class="col">
								<h4>Черкасова Лилия</h4>
								<p class="mb-1"><i class="fas fa-phone-alt"></i> 8-800-800-80-80</p>
								<p><i class="fas fa-envelope"></i> mail@mail.ru</p>
							</div>
						</div>
						<div class="row">
							<div class="col">
								<h4>Мы нахидимся по адресу:</h4>
								<p><i class="fas fa-map-marker-alt"></i> г. Рязань, ул. ...</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div id="first-block" class="container-fluid pt-5 pb-5">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-5">
						<ul>
							<li><h5><i class="fas fa-check"></i> Поможем вернуть Ваши права</h5></li>
							<li><h5><i class="fas fa-check"></i> Восстановить Вас на работе</h5></li>
							<li><h5><i class="fas fa-check"></i> Щашетим Ваше право потребителя</h5></li>
						</ul>
					</div>
					<div class="col-md-7">
						<p>Здесь какой то красивый текст про наши достоинства и опыт работ, наши преимущества и т.д. Здесь какой то красивый текст про наши достоинства и опыт работ, наши преимущества и т.д.</p>
					</div>
				</div>
			</div>
		</div>
		
		<div id="people-sevices" class="container-fluid bg-light pt-5 pb-5">
			<div class="container">
				<div class="row">
					<div class="col text-center mb-4">
						<h2>Услуги гражданам</h2>
					</div>
				</div>
				<div class="row justify-content-center align-items-center">
					
					<?php
					
						$result = mysqli_query($connection, "SELECT * FROM `services` WHERE `serviceParentID` = '9'");
						while ($record = mysqli_fetch_assoc($result)) {
							echo '
								<div class="col-md-4 mb-4">
									<div class="card w-100 text-white" style="background: url(img/service6.jpg);">
										<div class="overlay">
										</div>
										<div class="card-body">
											<h5 class="card-title">'.$record['serviceName'].'</h5>
											<a href="index.php?page=service-content&serviceID='.$record['serviceID'].'" class="btn btn-primary">Подробнее</a>
										</div>
									</div>
								</div>
							';
						}
					
					?>
					
				</div>
			</div>
		</div>
		
		<div id="company-sevices" class="container-fluid bg-white pt-5 pb-5">
			<div class="container">
				<div class="row">
					<div class="col text-center mb-4">
						<h2>Услуги организациям</h2>
					</div>
				</div>
				<div class="row justify-content-center align-items-center">
					
					<?php
					
						$result = mysqli_query($connection, "SELECT * FROM `services` WHERE `serviceParentID` = '10'");
						while ($record = mysqli_fetch_assoc($result)) {
							echo '
								<div class="col-md-4 mb-4">
									<div class="card w-100 text-white" style="background: url(img/service6.jpg);">
										<div class="overlay">
										</div>
										<div class="card-body">
											<h5 class="card-title">'.$record['serviceName'].'</h5>
											<a href="index.php?page=service-content&serviceID='.$record['serviceID'].'" class="btn btn-primary">Подробнее</a>
										</div>
									</div>
								</div>
							';
						}
					
					?>
					
				</div>
			</div>
		</div>
		
		<div id="complementary-sevices" class="container-fluid bg-light pt-5 pb-5">
			<div class="container">
				<div class="row">
					<div class="col text-center mb-4">
						<h2>Дополнительные услуги</h2>
					</div>
				</div>
				<div class="row justify-content-center align-items-center">
					
					<?php
					
						$result = mysqli_query($connection, "SELECT * FROM `services` WHERE `serviceParentID` = '11'");
						while ($record = mysqli_fetch_assoc($result)) {
							echo '
								<div class="col-md-4 mb-4">
									<div class="card w-100 text-white" style="background: url(img/service6.jpg);">
										<div class="overlay">
										</div>
										<div class="card-body">
											<h5 class="card-title">'.$record['serviceName'].'</h5>
											<a href="index.php?page=service-content&serviceID='.$record['serviceID'].'" class="btn btn-primary">Подробнее</a>
										</div>
									</div>
								</div>
							';
						}
					
					?>
					
				</div>
			</div>
		</div>
		
		<div id="client-feedback" class="container-fluid bg-white pt-5 pb-5">
			<div class="container">
				<div class="row">
					<div class="col text-center mb-4">
						<h2>Отзывы наших клиентов</h2>
					</div>
				</div>
				<div class="row align-items-center">
					<div class="col-md-3 mb-4">
						<div class="zoom">
							<img src="img/letter1.jpg">
						</div>
					</div>
					<div class="col-md-3 mb-4">
						<div class="zoom">
							<img src="img/letter1.jpg">
						</div>
					</div>
					<div class="col-md-3 mb-4">
						<div class="zoom">
							<img src="img/letter1.jpg">
						</div>
					</div>
					<div class="col-md-3 mb-4">
						<div class="zoom">
							<img src="img/letter1.jpg">
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div id="paerners" class="container-fluid bg-light pt-5 pb-5">
			<div class="container">
				<div class="row">
					<div class="col text-center mb-4">
						<h2>Партнеры и сотрудники</h2>
					</div>
				</div>
				<div class="row align-items-center">
					<div class="col-md-6 mb-4">
						<div class="card mb-3 w-100">
							<div class="row no-gutters">
								<div class="col-md-4">
									<img src="img/partner1.jpg" class="card-img" alt="...">
								</div>
								<div class="col-md-8">
									<div class="card-body">
										<h5 class="card-title">Партнер 1</h5>
										<p class="mb-1"><i class="fas fa-phone-alt"></i> 8-800-800-80-80</p>
										<p><i class="fas fa-envelope"></i> mail@mail.ru</p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6 mb-4">
						<div class="card mb-3 w-100">
							<div class="row no-gutters">
								<div class="col-md-4">
									<img src="img/partner1.jpg" class="card-img" alt="...">
								</div>
								<div class="col-md-8">
									<div class="card-body">
										<h5 class="card-title">Партнер 2</h5>
										<p class="mb-1"><i class="fas fa-phone-alt"></i> 8-800-800-80-80</p>
										<p><i class="fas fa-envelope"></i> mail@mail.ru</p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6 mb-4">
						<div class="card mb-3 w-100">
							<div class="row no-gutters">
								<div class="col-md-4">
									<img src="img/partner1.jpg" class="card-img" alt="...">
								</div>
								<div class="col-md-8">
									<div class="card-body">
										<h5 class="card-title">Партнер 3</h5>
										<p class="mb-1"><i class="fas fa-phone-alt"></i> 8-800-800-80-80</p>
										<p><i class="fas fa-envelope"></i> mail@mail.ru</p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6 mb-4">
						<div class="card mb-3 w-100">
							<div class="row no-gutters">
								<div class="col-md-4">
									<img src="img/partner1.jpg" class="card-img" alt="...">
								</div>
								<div class="col-md-8">
									<div class="card-body">
										<h5 class="card-title">Партнер 4</h5>
										<p class="mb-1"><i class="fas fa-phone-alt"></i> 8-800-800-80-80</p>
										<p><i class="fas fa-envelope"></i> mail@mail.ru</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Contacts -->
		<div id="contacts" class="container-fluid">
			<div class="overlay-dark">
			</div>
			<div class="container pt-5 pb-5">
				<div class="row">
					<div class="col text-center mb-4">
						<h4 class="text-white font-weight-normal">Если у Вас есть вопросы напишите нам</h4>
					</div>
				</div>
				<div class="row justify-content-center text-white">
					<div class="col-md-6">
						<form method="post" action="mails/mail3.php">
							<input type="text" class="form-control" name="name" placeholder="Введите Ваше имя" style="margin-bottom: 15px; display: inline;" required>
							<input type="text" class="form-control" name="mail" placeholder="Введите Ваш e-mail" style="margin-bottom: 15px; display: inline;" required>
							<textarea class="form-control" name="mes" placeholder="Введите Ваше сообщение" style="margin-bottom: 10px; display: inline;" required></textarea>
							<!-- reCAPTCHA v3 --
							<input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response">
							-->
							<button type="submit" class="btn btn-primary d-block w-100">Отправить</button>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- Contacts -->