<!doctype html>
<html lang="en">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		
		<!-- Style CSS -->
		<link rel="stylesheet" href="css/style.css">
		
		
		<script src="https://kit.fontawesome.com/064ae6a0a2.js"></script>

		<title>Hello, world!</title>
	</head>
	<body>
		
		<?php include 'navbar.php'; ?>
		
		<div id="main" class="container-fluid">
			<div class="overlay">
			</div>
			<div class="container pt-5 pb-5">
				<div class="row justify-content-end text-white">
					<div class="col">
						<h1 class="text-white text-center">Полезная информация</h1>
					</div>
				</div>
			</div>
		</div>
		
		<div id="people-sevices" class="container-fluid bg-white pt-5 pb-5">
			<div class="container">
				<div class="row">
					<div class="col text-center mb-4">
						<h2>Название какой нибудь интересной темы</h2>
					</div>
				</div>
				<div class="row align-items-center">
					<div class="col">
						<p>Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации.</p>
						<p>Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации.</p>
						<p>Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации. Здесь будет текст какой-нибудь полезной информации.</p>
					</div>
				</div>
			</div>
		</div>
		

		
		<!-- Contacts -->
		<div id="contacts" class="container-fluid">
			<div class="overlay-dark">
			</div>
			<div class="container pt-5 pb-5">
				<div class="row">
					<div class="col text-center mb-4">
						<h4 class="text-white font-weight-normal">Если у Вас есть вопросы напишите нам</h4>
					</div>
				</div>
				<div class="row justify-content-center text-white">
					<div class="col-md-6">
						<form method="post" action="mails/mail3.php">
							<input type="text" class="form-control" name="name" placeholder="Введите Ваше имя" style="margin-bottom: 15px; display: inline;" required>
							<input type="text" class="form-control" name="mail" placeholder="Введите Ваш e-mail" style="margin-bottom: 15px; display: inline;" required>
							<textarea class="form-control" name="mes" placeholder="Введите Ваше сообщение" style="margin-bottom: 10px; display: inline;" required></textarea>
							<!-- reCAPTCHA v3 --
							<input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response">
							-->
							<button type="submit" class="btn btn-primary d-block w-100">Отправить</button>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- Contacts -->