<!doctype html>
<html lang="ru">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		
		<!-- Style CSS -->
		<link rel="stylesheet" href="css/style.css">
		
		<script src="https://kit.fontawesome.com/064ae6a0a2.js"></script>

		<title>Hello, world!</title>
	</head>
	<body>
		
		<?php include 'navbar.php'; ?>
		
		<div id="main" class="container-fluid">
			<div class="overlay">
			</div>
			<div class="container pt-5 pb-5">
				<div class="row justify-content-end text-white">
					<div class="col">
						<h1 class="text-white text-center">Партнеры и сотрудники</h1>
					</div>
				</div>
			</div>
		</div>
		
		<div class="container-fluid bg-wjite pt-5 pb-4">
			<div class="container">
				<div class="row">
					<div class="col-md-4 mb-4">
						<img src="img/partner1.jpg" class="card-img" alt="...">
					</div>
					<div class="col-md-8 mb-4">
						<h4>Фамилия, имя и отчество партнера</h4>
						<p>Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов.</p>
						<p class="mb-1"><i class="fas fa-phone-alt"></i> 8-800-800-80-80</p>
						<p><i class="fas fa-envelope"></i> mail@mail.ru</p>
					</div>
				</div>
				<div class="row align-items-center">
					
				</div>
			</div>
		</div>
		
		<div id="client-feedback" class="container-fluid bg-light pt-4 pb-5">
			<div class="container">
				<div class="row">
					<div class="col text-center mb-4">
						<h3>Благодарности и отзывы клиентов</h3>
					</div>
				</div>
				<div class="row align-items-center">
					<div class="col-md-3 mb-4">
						<div class="zoom">
							<img src="img/letter1.jpg">
						</div>
					</div>
					<div class="col-md-3 mb-4">
						<div class="zoom">
							<img src="img/letter1.jpg">
						</div>
					</div>
					<div class="col-md-3 mb-4">
						<div class="zoom">
							<img src="img/letter1.jpg">
						</div>
					</div>
					<div class="col-md-3 mb-4">
						<div class="zoom">
							<img src="img/letter1.jpg">
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="container-fluid bg-wjite pt-5 pb-4">
			<div class="container">
				<div class="row">
					<div class="col-md-4 mb-4">
						<img src="img/partner1.jpg" class="card-img" alt="...">
					</div>
					<div class="col-md-8 mb-4">
						<h4>Фамилия, имя и отчество партнера</h4>
						<p>Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов. Здесь какой-то полезный текст о Вас для клиентов.</p>
						<p class="mb-1"><i class="fas fa-phone-alt"></i> 8-800-800-80-80</p>
						<p><i class="fas fa-envelope"></i> mail@mail.ru</p>
					</div>
				</div>
				<div class="row align-items-center">
					
				</div>
			</div>
		</div>
		
		<div id="client-feedback" class="container-fluid bg-light pt-4 pb-5">
			<div class="container">
				<div class="row">
					<div class="col text-center mb-4">
						<h3>Благодарности и отзывы клиентов</h3>
					</div>
				</div>
				<div class="row align-items-center">
					<div class="col-md-3 mb-4">
						<div class="zoom">
							<img src="img/letter1.jpg">
						</div>
					</div>
					<div class="col-md-3 mb-4">
						<div class="zoom">
							<img src="img/letter1.jpg">
						</div>
					</div>
					<div class="col-md-3 mb-4">
						<div class="zoom">
							<img src="img/letter1.jpg">
						</div>
					</div>
					<div class="col-md-3 mb-4">
						<div class="zoom">
							<img src="img/letter1.jpg">
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Contacts -->
		<div id="contacts" class="container-fluid">
			<div class="overlay-dark">
			</div>
			<div class="container pt-5 pb-5">
				<div class="row">
					<div class="col text-center mb-4">
						<h4 class="text-white font-weight-normal">Если у Вас есть вопросы напишите нам</h4>
					</div>
				</div>
				<div class="row justify-content-center text-white">
					<div class="col-md-6">
						<form method="post" action="mails/mail3.php">
							<input type="text" class="form-control" name="name" placeholder="Введите Ваше имя" style="margin-bottom: 15px; display: inline;" required>
							<input type="text" class="form-control" name="mail" placeholder="Введите Ваш e-mail" style="margin-bottom: 15px; display: inline;" required>
							<textarea class="form-control" name="mes" placeholder="Введите Ваше сообщение" style="margin-bottom: 10px; display: inline;" required></textarea>
							<!-- reCAPTCHA v3 --
							<input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response">
							-->
							<button type="submit" class="btn btn-primary d-block w-100">Отправить</button>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- Contacts -->